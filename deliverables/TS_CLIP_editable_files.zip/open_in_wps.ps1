param([string]$Path = (Join-Path $PSScriptRoot 'TS_CLIP_editable_reconstruction.pptx'))
$ErrorActionPreference = 'Stop'
$fullPath = (Resolve-Path -LiteralPath $Path).Path
$app = New-Object -ComObject 'KWPP.Application'
$app.Visible = -1
# ReadOnly=false, Untitled=false, WithWindow=true. Keep WPS open for editing.
$presentation = $app.Presentations.Open($fullPath, 0, 0, -1)
Write-Host ('Opened in visible WPS: ' + $fullPath)
Write-Host ('Slides: ' + $presentation.Slides.Count)
